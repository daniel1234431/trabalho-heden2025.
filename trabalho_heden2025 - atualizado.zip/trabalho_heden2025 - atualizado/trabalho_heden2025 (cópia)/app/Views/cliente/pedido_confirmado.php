<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #fafafa;
        color: #333;
        padding: 20px;
    }

    h2 {
        text-align: center;
        color: #2E7D32; /* verde escuro para combinar */
        margin-bottom: 10px;
        font-weight: 700;
    }

    h3 {
        color: #43A047; /* verde esmeralda */
        margin-top: 30px;
        margin-bottom: 15px;
        font-weight: 600;
        text-align: center;
    }

    p {
        text-align: center;
        font-size: 1.1rem;
        margin: 10px 0 20px;
    }

    table {
        width: 100%;
        border-collapse: separate; 
        border-spacing: 0;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        border-radius: 12px;
        overflow: hidden; 
        background-color: #fff;
        margin: 0 auto 40px;
        max-width: 900px;
    }

    thead tr {
        background-color: #43A047; 
        color: #fff;
        font-weight: 600;
        text-transform: uppercase;
    }

    th, td {
        padding: 14px 20px;
        text-align: left;
        border-bottom: 1px solid #e0e0e0;
        font-size: 1rem;
    }

    tbody tr:hover {
        background-color: #f1f9f1;
        transition: background-color 0.3s ease;
    }

  
    tbody tr:last-child td {
        border-bottom: none;
    }

    a {
        display: inline-block;
        margin: 20px auto 0;
        text-decoration: none;
        color: #fff;
        background-color: #2E7D32;
        padding: 12px 25px;
        border-radius: 25px;
        font-weight: 600;
        font-size: 1.1rem;
        text-align: center;
        transition: background-color 0.3s ease, box-shadow 0.3s ease;
        box-shadow: 0 4px 8px rgba(46,125,50,0.3);
    }

    a:hover {
        background-color: #145214;
        box-shadow: 0 6px 12px rgba(20,82,20,0.5);
    }
</style>


<h2>Obrigado pela sua compra!</h2>
<p>Seu pedido foi confirmado com sucesso.</p>
<a href="<?= base_url('cliente/loja') ?>">Voltar à loja</a>

<h2>Pedido Confirmado!</h2>

<?php if (!empty($produtos)): ?>
    <h3>Produtos comprados:</h3>
    <table>
        <thead>
            <tr>
                <th>Produto</th>
                <th>Quantidade</th>
                <th>Preço Unitário</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($produtos as $produto): ?>
                <tr>
                    <td><?= esc($produto['nome']) ?></td>
                    <td><?= esc($produto['quantidade']) ?></td>
                    <td>R$ <?= number_format($produto['preco'], 1, ',', '.') ?></td>
                    <td>R$ <?= number_format($produto['preco'] * $produto['quantidade'], 1, ',', '.') ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>Nenhum produto encontrado no pedido.</p>
<?php endif; ?>
