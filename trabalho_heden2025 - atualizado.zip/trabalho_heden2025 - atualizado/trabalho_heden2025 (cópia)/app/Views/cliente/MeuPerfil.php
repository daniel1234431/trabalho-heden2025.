<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <title>Perfil do Cliente</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #e8f5e9;
      color: #014421;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    .perfil-container {
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      width: 350px;
      text-align: center;
    }
    h2 {
      margin-bottom: 20px;
      color: #00796b;
    }
    p {
      font-size: 18px;
      margin: 10px 0;
    }
    .compras-container {
      margin-top: 30px;
      text-align: left;
    }
    .compra-item {
      background: #f1f1f1;
      margin-bottom: 15px;
      padding: 10px;
      border-radius: 8px;
    }
    a.btn-sair {
      display: inline-block;
      margin-top: 20px;
      background: #00796b;
      color: white;
      padding: 10px 20px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
      transition: background-color 0.3s ease;
    }
    a.btn-sair:hover {
      background-color: #004d40;
    }
  </style>
</head>
<body>

  <div class="perfil-container">
    <h2>Meu Perfil</h2>

    <h1>Bem-vindo, <?= esc($nome) ?>!</h1>
    <p>Nome: <?= esc($nome) ?></p>
    <p>Email: <?= esc($email) ?></p>

    <!-- Se houver compras realizadas -->
    <?php if (!empty($compras)): ?>
      <div class="compras-container">
        <h3>Compras Realizadas</h3>
        <?php foreach ($compras as $compra): ?>
          <div class="compra-item">
            <p><strong>Produto:</strong> <?= esc($compra['produto_nome']) ?></p>
            <p><strong>Data da Compra:</strong> <?= esc($compra['data_compra']) ?></p>
            <p><strong>Status:</strong> <?= esc($compra['status']) ?></p>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p>Você ainda não fez nenhuma compra.</p>
    <?php endif; ?>

    <!-- Botão Sair -->
    <a href="<?= base_url('cliente/login') ?>" class="btn-sair">Sair</a>
    <br>
    <a href="<?= base_url('cliente/index') ?>" class="btn-sair">Voltar</a>
  </div>

</body>
</html>
