<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar</title>
    <!-- Seu CSS atual permanece o mesmo -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        /* Reset básico */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Corpo da página */
body {
  font-family: Arial, sans-serif;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color:#e8f5e9;
  
}

/* Container do formulário */
.form-container {
  background-color: #ffffffee;
  padding: 20px;
  border-radius: 15px;
  box-shadow: 0 10px 16px rgba(0,0,0,0.1);
  width: 100%;
  max-width: 400px;
  box-shadow: 0 6px 10px rgba(0,0,0,0.3);
  animation: fadeIn 0.6s ease-in-out;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
}

/* Título */
.titl {
  text-align: center;
  font-size: 28px;
  color: #2e7d32;
  margin-bottom: 25px;
  
}

/* Campos do formulário */
.form2 {
  margin-bottom: 15px;
}

label {
  display: block;
  margin-bottom: 6px;
  font-weight: bold;
  color: #333;
  
}

input[type="nome"],
input[type="email"],
input[type="telefone"],
input[type="password"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 8px;
  box-sizing: border-box;
  transition: border-color 0.3s;
    box-shadow: 0 6px 10px rgba(0,0,0,0.3);
  animation: fadeIn 0.6s ease-in-out;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
}

input[type="nome"]:focus,
input[type="email"]:focus,
input[type="telefone"]:focus,
input[type="password"]:focus {
  border-color: #4CAF50;
  outline: none;
}

/* Botão principal */
button {
  width: 100%;
  padding: 12px;
  background-color: #4CAF50;
  color: white;
  border: none;
  font-size: 16px;
  cursor: pointer;
  border-radius: 8px;
  transition: background-color 0.3s, transform 0.2s, box-shadow 0.2s;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
  box-shadow: 0 6px 10px rgba(0,0,0,0.3);
  animation: fadeIn 0.6s ease-in-out;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
}

button:hover {
  background-color: #388e3c;
  transform: translateY(-2px);
  box-shadow: 0 6px 12px rgba(0,0,0,0.15);
}

/* Links extras */
.voltar, .link-extra {
  text-align: center;
  margin-top: 15px;
}

.voltar a, .link-extra a {
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
  transition: color 0.3s;
}

.voltar a:hover, .link-extra a:hover {
  color: #0056b3;
  text-decoration: underline;
}

/* Responsivo */
@media (max-width: 500px) {
  .form-container {
    padding: 20px;
  }
}
.top-text {
  position: absolute;
  top: 15px;
  left: 15px;
  z-index: 999;
  background-color: rgba(255, 255, 255, 0.85);
  padding: 8px 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.top-text h3 {
  
  margin: 0;
  font-size: 1rem;
  font-weight: normal;
}
.btn-voltar {
  display: inline-block;
  width: 100%;
  padding: 12px;
  background-color: #4CAF50;
  color: white;
  border: none;
  font-size: 16px;
  cursor: pointer;
  border-radius: 8px;
  text-align: center;
  text-decoration: none;
  transition: background-color 0.3s, transform 0.2s, box-shadow 0.2s;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
  margin-top: 10px; /* para espaçar do botão cadastrar */
  box-shadow: 0 6px 10px rgba(0,0,0,0.3);
  animation: fadeIn 0.6s ease-in-out;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
}

.btn-voltar:hover {
  background-color: #388e3c;
  transform: translateY(-2px);
  box-shadow: 0 6px 12px rgba(0,0,0,0.15);
}

    .footer {
  text-align: center;
  padding: 20px;
  font-weight: bold;
  color: white;
  background-color: var(--verde-escuro);
  border-top: 4px solid #81C784;
  animation: fadeIn 0.8s ease-in-out;
}

    @keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
.header {
      background-color: var(--verde-escuro);
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
      box-shadow: 0 4px 12px var(--sombra);
      animation: slideDown 0.5s ease-out;
    }

    .nav-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 20px;
      max-width: 1400px;
      margin: 0 auto;
    }

    .logo {
      display: flex;
      align-items: center;
      color: var(--branco);
      text-decoration: none;
      font-weight: bold;
      font-size: 1.5rem;
      padding: 15px 0;
    }

    .logo img {
      height: 40px;
      margin-right: 10px;
    }

    .menu-toggle {
      display: none;
      background: none;
      border: none;
      color: var(--branco);
      font-size: 1.5rem;
      cursor: pointer;
    }

    .menu-items {
      display: flex;
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .menu-items li {
      position: relative;
    }

    .menu-items a {
      color: var(--branco);
      text-decoration: none;
      padding: 20px 15px;
      display: block;
      font-weight: 500;
      transition: all 0.3s ease;
      position: relative;
    }

    .menu-items a:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    .menu-items a::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      width: 0;
      height: 3px;
      background: var(--branco);
      transition: all 0.3s ease;
      transform: translateX(-50%);
    }

    .menu-items a:hover::after {
      width: 80%;
    }

    .menu-items i {
      margin-right: 8px;
    }

    /* Conteúdo Principal */
    .main-content {
      padding-top: 80px;
      padding-bottom: 60px;
    }

    /* Restante do seu CSS existente */
    .container-wrapper {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 30px;
      margin: 40px auto;
      max-width: 1400px;
      transition: 
        background-color 0.3s ease, 
        transform 0.2s ease, 
        box-shadow 0.3s ease, 
        filter 0.3s ease;
      box-shadow: 0 4px 6px rgba(0,0,0,0.9);
      animation: fadeIn 0.6s ease-in-out;
    }

    .container {
      flex: 1 1 400px;
      max-width: 500px;
      background-color: rgba(255, 255, 255, 0.85);
      border-radius: 15px;
      padding: 30px;
      box-shadow: 0 6px 10px rgba(0,0,0,0.3);
      animation: fadeIn 0.6s ease-in-out;
      transition: 
        background-color 0.3s ease, 
        transform 0.2s ease, 
        box-shadow 0.3s ease, 
        filter 0.3s ease;
    }

    .titulo1 {
      font-size: 24px;
      color: var(--verde-escuro);
      margin-bottom: 15px;
    }

    .btn {
      background-color: var(--verde-escuro);
      color: white;
      padding: 12px 24px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: bold;
      text-decoration: none;
      display: inline-block;
      transition: all 0.3s ease;
      box-shadow: 0 4px 6px rgba(0,0,0,0.3);
      animation: fadeIn 0.6s ease-in-out;
      position: relative;
      overflow: hidden;
    }

    .btn:hover {
      background-color: var(--verde-esmeralda);
      transform: translateY(-3px);
      box-shadow: 0 6px 12px rgba(0,0,0,0.2);
      animation: bounce 0.5s ease;
    }

    .btn:active {
      transform: translateY(1px);
    }

    .btn::after {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      width: 5px;
      height: 5px;
      background: rgba(255, 255, 255, 0.5);
      opacity: 0;
      border-radius: 100%;
      transform: scale(1, 1) translate(-50%);
      transform-origin: 50% 50%;
    }

    .button-container .btn {
      width: 100%;
      margin-top: 15px;
    }

    
    form input[type="text"] {
      padding: 12px;
      width: 100%;
      border-radius: 8px;
      border: 1px solid #ccc;
      margin-bottom: 15px;
      transition: all 0.3s ease;
      box-shadow: 0 2px 4px rgba(0,0,0,0.9);
    }

    /* Rodapé */
    .footer {
      text-align: center;
      padding: 20px;
      font-weight: bold;
      color: white;
      background-color: var(--verde-escuro);
      border-top: 4px solid #81C784;
      animation: fadeIn 0.8s ease-in-out;
      position: fixed;
      bottom: 0;
      width: 100%;
    }

   
    @media (max-width: 768px) {
      .menu-toggle {
        display: block;
      }

      .menu-items {
        
        top: 70px;
        left: -100%;
        width: 80%;
        height: calc(100vh - 70px);
        background-color: var(--verde-escuro);
        flex-direction: column;
        transition: all 0.5s ease;
        box-shadow: 2px 0 5px var(--sombra);
      }

      .menu-items.active {
        left: 0;
      }

      .menu-items li {
        width: 100%;
      }

      .menu-items a {
        padding: 15px 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }

      .main-content {
        padding-top: 70px;
      }

      .container {
        margin: 15px;
        padding: 20px;
      }
    }
    :root {
      --verde-esmeralda: #43A047;
      --verde-principal: #2E7D32;
      --verde-escuro: #014421;
      --branco: #FFFFFF;
      --sombra: rgba(0,0,0,0.2);
    } 
    </style>
</head>
<body>

<!-- Menu -->
<header class="header">
    <div class="nav-container">
        <a href="<?=base_url('cliente/index')?>" class="logo">
            <i data-lucide="leaf"></i> Artesana
        </a>
        
        <button class="menu-toggle" id="menuToggle">
            <i data-lucide="menu"></i>
        </button>
        
        <ul class="menu-items" id="menuItems">
            <li><a href="<?=base_url('cliente/index')?>"><i data-lucide="home"></i> Início</a></li>
            <li><a href="<?=base_url('cliente/sobre')?>"><i data-lucide="info"></i> Sobre</a></li>
            <li><a href="<?=base_url('cliente/serviços')?>"><i data-lucide="briefcase"></i> Serviços</a></li>
            <li><a href="<?=base_url('cliente/loja')?>"><i data-lucide="shopping-bag"></i> Produtos</a></li>
            <li><a href="<?=base_url('cliente/contato')?>"><i data-lucide="mail"></i> Contato</a></li>
        </ul>
    </div>
</header>

<!--corpo do inicio-->
<div class="main-content">
    <div class="form-container">
        <?php if (session()->getFlashdata('mensagem')): ?>
            <div style="background-color: #d4edda; color: #155724; padding: 10px; border-radius: 8px; margin-bottom: 15px; text-align: center;">
                <?= session()->getFlashdata('mensagem') ?>
            </div>
        <?php endif; ?>

        <h1 class="titl">Cadastrar</h1>

        <?= form_open('Cliente/inserir') ?>
            <!-- Nome -->
            <div class="form2">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" placeholder="Digite seu nome" required>
            </div>

            <!-- Telefone -->
            <div class="form2">
                <label for="telefone">Telefone:</label>
                <input type="telefone" name="telefone" id="telefone" placeholder="Digite seu número de telefone" required>
            </div>

            <!-- Email -->
            <div class="form2">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" placeholder="nome@gmail.com" required>
            </div>

            <!-- Senha -->
            <div class="form2">
                <label for="senha">Senha:</label>
                <input type="password" name="senha" id="senha" autocomplete="off" required>
                <div id="passwordHelpBlock" class="form-text">
                    Sua senha deve ter pelo menos 8 caracteres, incluindo letras e números.
                </div>
            </div>

            <!-- Confirmar a senha -->
            <div class="form2">
                <label for="confirma_senha">Confirmar senha:</label>
                <input type="password" name="confirma_senha" id="confirma_senha" autocomplete="off" required>
            </div>

            <!-- Botão de cadastrar -->
            <div class="form2">
                <button type="submit">Cadastrar</button>
            </div>

        <?= form_close() ?>
        
            <a class="btn-voltar" href="<?=base_url('cliente/index')?>">Voltar</a>
            <div class="link-extra">
        <p>Já tem uma conta? <a href="<?=base_url('cliente/login')?>">Fazer login</a></p>
    
</div>





<script>
    lucide.createIcons();

   
    document.getElementById("menuToggle").addEventListener("click", function () {
        document.getElementById("menuItems").classList.toggle("active");
    });
</script>
<script>
  lucide.replace();
</script>
</body>

</body>
</html>
