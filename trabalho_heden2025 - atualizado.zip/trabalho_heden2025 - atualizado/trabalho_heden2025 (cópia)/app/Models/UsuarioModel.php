<?php
namespace App\Models;

use CodeIgniter\Model;

class UsuarioModel extends Model
{
    protected $table = 'cliente';
    protected $primaryKey = 'id';
    protected $allowedFields = ['email', 'senha', 'nome'];

    public function verificarLogin($email, $senha)
    {
        $usuario = $this->where('email', $email)->first();

        if (!$usuario) {
            return false;  // usuário não encontrado
        }

        if (password_verify($senha, $usuario['senha'])) {
            return $usuario;  // login válido
        }

        return false;  // senha incorreta

       
$usuario = $usuarioModel->where('email', $email)->first();

if ($usuario && password_verify($senha, $usuario['senha'])) {
    // login válido, criar sessão
} else {
    // login inválido
}

    }
    
}
