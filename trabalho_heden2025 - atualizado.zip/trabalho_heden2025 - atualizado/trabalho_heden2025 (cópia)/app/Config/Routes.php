<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Página inicial
$routes->get('/', 'Cliente::index');

// Google Login callback
$routes->post('Cliente/google_callback', 'Cliente::google_callback');

// Carrinho de compras
$routes->post('/carrinho/adicionar', 'Carrinho::adicionar');
$routes->get('/carrinho/ver', 'Carrinho::ver');
$routes->get('/cliente/carrinho', 'CarrinhoController::index');
$routes->get('/cliente/carrinho/adicionar/(:num)', 'CarrinhoController::adicionar/$1');

// Login e autenticação
$routes->get('/login', 'Auth::login'); 
//$routes->get('login', 'Login::index');


$routes->post('/auth/autenticar', 'Auth::autenticar'); // Verifica email/senha
$routes->get('/auth/logout', 'Auth::logout');

// Dashboard e Perfil
$routes->get('/dashboard', 'Dashboard::index', ['filter' => 'auth']);
$routes->get('/perfil', 'Usuario::perfil', ['filter' => 'auth']);


// Loja

$routes->get('loja', 'Cliente::loja');
$routes->get('/loja', 'Loja::index');
$routes->get('/cliente', 'Cliente::index');


$routes->post('/cliente/autenticar', 'Cliente::autenticar');

$routes->post('cliente/confirmar-pedido', 'Cliente::confirmarPedido');
$routes->get('cliente/pedido-confirmado', 'Cliente::pedidoConfirmado');
$routes->get('cliente/pedido', 'Cliente::pedido');



$routes->get('contato', 'ContatoController::index');
$routes->post('contato/enviar', 'ContatoController::enviar');
$routes->get('contato/sucesso', 'ContatoController::sucesso');

$routes->get('cliente/suaconta', 'Cliente::Suaconta');




$routes->get('login', 'Auth::login'); // mostrar formulário
$routes->post('login', 'Auth::loginPost'); // processar formulário

$routes->group('', ['filter' => 'auth'], function($routes) {
    $routes->get('/dashboard', 'Dashboard::index');
   
});





$routes->setAutoRoute(true);



