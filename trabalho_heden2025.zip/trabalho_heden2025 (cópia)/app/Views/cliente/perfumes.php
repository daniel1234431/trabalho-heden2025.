<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Barra de Pesquisa + Galeria</title>
  <style>
    
 
    .st {
  width: 100%;
  max-width: 250px;
  height: auto;
  border-radius: 15px;
  margin-top: 20px;
  object-fit: cover;
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
}

  body {
  font-family: Arial, sans-serif;
  padding: 20px;
  background-color:#d0f0c0; 
  color: #424242; 
  transition: opacity 0.9s ease;
  background-image: url('/fnd2.jpg');
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  
}


#searchInput {
  width: 300px;
  padding: 8px;
  font-size: 10px;
  border: 1px solid #81C784;
  border-radius: 8px;
  background-color: #F5F5F5;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.9);
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
}

ul {
  margin-top: 10px;
  border-radius: 30px;
  font-weight: bold;
}

li {
  margin: 5px 0;
}

.div4 {
  position: fixed;
  top: 9px;
  left: 12px;
  background-color:white;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 15px;
  z-index: 1000;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.9);
  border-radius: 8px;
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
 
}
.ps {
  color:black;
  font-size: 22px;
  margin: 0;
}
.div4 h2 {
  margin-right: 10px;
}

.li1 a {
  text-decoration: none;
  color: #2E7D32;
  padding: 5px 10px;
  border-radius: 4px;
  transition: background-color 0.3s;
}

.li1 a:hover {
  background-color:black;
}

.topo {
  background-color:#014421;
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 7px;
  width: 100%;
  z-index: 1000;
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
  
}

.topo li a {
  color: white;
  
}

.topo li a:hover {
  background-color: #81C784;
  display: inline-block;
  text-decoration: none;
  color: white;
  background: linear-gradient(45deg, var(--verde-esmeralda), var(--verde-principal));
  padding: 12px 25px;
  border-radius: 8px;
  font-size: 16px;
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
}

.galeria {
  background-color:transparent;
  display: flex;
  flex-wrap: wrap;
  gap: 30px;
  justify-content: center;
  margin-top: 40px;
  padding: 20px;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
  
  
}

.imagem-container1 {
  margin-bottom: 20px;
  border: 2px solid #A5D6A7;
  padding: 20px;
  background-color:transparent;
  border-radius: 15px;
  width: 400px;
  text-align: center;
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
  
}

.imagem-container1 p {
  margin-top: 8px;
  font-size: 14px;
}
.produto-img {
  width: 100%;
  max-width: 250px;
  height: 250px;
  object-fit: cover;
  border-radius: 15px;
  margin-top: 20px;
}


.img1 { border: 2px solid #A5D6A7; }
.img2 { border: 2px solid #81C784; }
.img3 { border: 2px solid #66BB6A; }



@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
.search-button {
  position: absolute;
  top: 50%;
  left: 10px;
  transform: translateY(-50%);
  background: transparent;
  border: none;
  cursor: pointer;
}
.search-button i {
  font-size: 18px;
  color: #555; /* Cor do ícone */
}

.linkt {
  font-family: 'Montserrat', sans-serif;
    font-weight: 700;
    font-size: 1em;
  text-decoration: none;
  color:white;
  font-weight: bold;
  padding: 5px 10px;
}

.linkt:hover {
  color: white;
  
  border-radius: 4px;
}



.cart-icon {
  font-size: 20px;
  margin-right: 5px;
}

.cart-button {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
}
.cart-button {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
}

.cart-button button {
  background-color: #014421;
  color: white;
  padding: 8px 15px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: bold;
  transition: transform 0.3s ease, background-color 0.3s ease;
}

.cart-button button:hover {
  background-color: #81C784;
  color: black;
  transform: scale(1.05);
}

@media (max-width: 500px) {
  .container, .container1 {
    padding: 20px;
  }

  .button-container a {
    width: 100%;
    padding: 12px 0;
    background-color: #2E7D32;
  }
}

.btn.btn-secondary.dropdown-toggle {
  background-color:	
#014421;
  color:white;
  border: none;
  padding: 10px 20px;
  border-radius: 10px;
  cursor: pointer;
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.9);
  animation: fadeIn 0.6s ease-in-out;
}


    
  </style>
</head>
<body>




<div class="div4">
  <h2 class="ps">Pesquisar itens</h2>
  <input class="pesquisa" type="text" id="searchInput" placeholder="Digite para buscar...">
</div>

<div class="drop" data-bs-theme="dark" style="position: fixed; top: 10px; right: 10px; z-index: 1000;">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButtonDark" data-bs-toggle="dropdown" aria-expanded="false">
    <span class="cart-icon"><i class="fas fa-shopping-cart"></i></span>
    <span class="cart-text">Ir para:</span>
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButtonDark">
    <li><a class="dropdown-item active" href="<?= base_url('cliente/carrinho') ?>">Carrinho</a></li>
    <li><a class="dropdown-item" href="<?= base_url('cliente/historico ') ?>">Historico</a></li>
    <li><a class="dropdown-item" href="<?= base_url('cliente/loja ') ?>">inicio</a></li>
  </ul>
</div>
<br>
<br>

<ul id="itemList">
  <ul class="topo">
    <li><a class="linkt" href="<?= base_url('cliente/perfumes') ?>">Perfumes</a></li>
    <li><a class="linkt" href="<?= base_url('cliente/roupas') ?>">Roupas</a></li>
    <li><a class="linkt" href="<?= base_url('cliente/sabonetes') ?>">Sabonetes</a></li>
    <li><a class="linkt" href="<?= base_url('cliente/esfoliantes') ?>">Esfoliantes</a></li>
    <li><a class="linkt" href="<?= base_url('cliente/cremes_hidratantes') ?>">Cremes/Hidratantes</a></li>
  </ul>
</ul>

<div class="galeria">
  <div class="imagem-container1">
    <img src="/image1.jpeg" alt="Produto 1" class="produto-img img1" id=1>
    <p class="linkt">Natura deo parfum feminino luna 50ml</p>
    <p class="linkt">R$ 149,99</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/1') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>

  <div class="imagem-container1">
    <img src="/image2.jpeg" alt="Produto 2" class="produto-img img2" id=1>
    <p class="linkt">Natura Kaiak oceano masculino 100ml</p>
    <p class="linkt">R$ 170,00</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/2') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>

  <div class="imagem-container1">
    <img src="/image3.jpeg" alt="Produto 3" class="produto-img img3" id=1>
    <p class="linkt">Natura colônia biografia</p>
    <p class="linkt">R$ 200,00</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/3') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>

  <div class="imagem-container1">
    <img src="/perfumee1.jpeg" alt="Produto 4" class="produto-img img4" id=1>
    <p class="linkt">Natura luna feminino</p>
    <p class="linkt">R$ 180,00</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/4') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>
</div>

<div class="galeria">
  <div class="imagem-container1">
    <img src="/perfume5.jpg" alt="Produto 5" class="produto-img img5" id=1>
    <p class="linkt">Oboticario clash masculino 100ml</p>
    <p class="linkt">R$ 200,00</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/5') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>

  <div class="imagem-container1">
    <img src="/image0.jpeg" alt="Produto 6" class="produto-img img6" id=1>
    <p class="linkt">Oboticario florata my blue 75ml</p>
    <p class="linkt">R$ 159,99</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/6') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>

  <div class="imagem-container1">
    <img src="/perfumee3.jpeg" alt="Produto 7" class="produto-img img7" id=1>
    <p class="linkt">Oboticario florata my blue 75ml</p>
    <p class="linkt">R$ 159,99</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/7') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>

  <div class="imagem-container1">
    <img src="/image8.jpeg" alt="Produto 8" class="produto-img img8" id=1>
    <p class="linkt">Natura essencial tradicional 100ml</p>
    <p class="linkt">R$ 150,00</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/8') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>
</div>


<script>
  const searchInput = document.getElementById("searchInput");
  const produtos = document.querySelectorAll(".imagem-container1");

  searchInput.addEventListener("keyup", function() {
    const filtro = searchInput.value.toLowerCase();

    produtos.forEach(produto => {
      const nome = produto.querySelector("p").textContent.toLowerCase();
      if (nome.includes(filtro)) {
        produto.style.display = "";
      } else {
        produto.style.display = "none";
      }
    });
  });
</script>

</body>
</html>
