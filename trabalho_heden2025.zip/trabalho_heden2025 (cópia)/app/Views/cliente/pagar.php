<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Formas de Pagamento</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e5f9e0;
            padding: 40px;
            text-align: center;
        }

        h1 {
            color:black;
            margin-bottom: 30px;
            font-size: 36px;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.9);
            transition: color 0.3s ease;
        }

        .formas-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
            align-items: center;
            max-width: 500px;
            margin: 0 auto;
        }

        .forma-linha {
            display: flex;
            align-items: center;
            justify-content: space-between;
            width: 100%;
            background-color: #ffffff;
            border: 2px solid #c8e6c9;
            border-radius: 12px;
            padding: 15px 20px;
            transition: transform 0.2s ease, box-shadow 0.3s ease;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .forma-linha:hover {
            transform: scale(1.02);
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
        }

        .forma p {
            margin: 0;
            font-size: 20px;
            color: #333;
        }

        .btn-pagar,
        .btn-voltar {
            background-color: #388e3c;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .btn-pagar:hover,
        .btn-voltar:hover {
            background-color: #2e7d32;
            transform: scale(1.05);
            box-shadow: 0 6px 12px rgba(0,0,0,0.2);
        }

        .btn-voltar {
            margin-top: 40px;
            display: inline-block;
        }
    </style>
</head>
<body>

    <h1>Escolha a Forma de Pagamento</h1>

    <div class="formas-container">

        <div class="forma-linha">
            <div class="forma">
                <p>💳 Cartão de Crédito</p>
            </div>
            <div class="button-container">
                <?= anchor('Cliente/pagar_cartao', 'Pagar', ['class' => 'btn-pagar']) ?>
            </div>
        </div>

        <div class="forma-linha">
            <div class="forma">
                <p>🏦 Boleto Bancário</p>
            </div>
            <div class="button-container">
                <?= anchor('Cliente/pagar_boleto', 'Pagar', ['class' => 'btn-pagar']) ?>
            </div>
        </div>

        <div class="forma-linha">
            <div class="forma">
                <p>💸 PIX</p>
            </div>
            <div class="button-container">
                <?= anchor('Cliente/pagar_pix', 'Pagar', ['class' => 'btn-pagar']) ?>
            </div>
        </div>

    </div>

    <a href="<?= base_url('cliente/loja') ?>" class="btn-voltar">Voltar para a loja</a>

</body>
</html>
