<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Nossos Serviços</title>
  
  
</head>
<style>
    body {
  font-family: Arial, sans-serif;
  margin: 0;
  background: #f5f5f5;
  color: #333;
}

header {
  background-color: #2E7D32;
  padding: 20px;
  text-align: center;
  color: white;
}

header nav a {
  color: white;
  margin: 0 15px;
  text-decoration: none;
  font-weight: bold;
}

header nav a:hover {
  text-decoration: underline;
}

.servicos {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  padding: 40px 20px;
  gap: 20px;
}

.servico {
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
  padding: 20px;
  width: 300px;
  text-align: center;
}

.servico h2 {
  color: #2E7D32;
}

footer {
  text-align: center;
  padding: 20px;
  background-color: #ccc;
  margin-top: 30px;
}

</style>
<body>

  <header>
    <h1>Nossos Serviços</h1>
    <nav>
    <a href="<?=base_url('cliente/index')?>">Início</a>
      <a href="<?=base_url('cliente/sobre')?>">Sobre</a>
      <a href="<?=base_url('cliente/serviços')?>">Serviços</a>
      <a href="<?=base_url('cliente/contato')?>">Contato</a>
    </nav>
  </header>

  <section class="servicos">
    <div class="servico">
      <h2>Entregas rápidas</h2>
      <p>Oferecemos uma entrega rapida e segura.</p>
    </div>

    <div class="servico">
      <h2>formas de pagamento</h2>
      <p>Pix,
        Cartão de crédito,
        Cartão de débito,
        Boleto,
        Transferência bancária
      </p>
    </div>

    <div class="servico">
      <h2>Suporte </h2>
      <p>Atendimento rápido e eficaz para resolver suas necessidades.</p>
    </div>

    <div class="servico">
      <h2>Tutorial de uso</h2>
      <p>videos de profissionais especializados de:
        <ul>
          <li>Como usar os produtos</li>
          <li>Quantidade recomendada</li>
          <li>beneficios e possiveis efeitos colaterais</li>
        </ul>
      </p>
    </div>
  </section>



</body>
</html>
