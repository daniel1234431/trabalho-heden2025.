<h1>Bem-vindo, <?= session('nome') ?>!</h1>
<a href="/auth/logout">Sair</a>
