<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ClienteModel;
use App\Models\UsuarioModel;
use App\Models\PedidoModel; 


class Cliente extends BaseController
{
    private $clienteModel;

    public function __construct(){
        $this->clienteModel = new ClienteModel();
    }

    public function Carrinho()
    {
        $session = session();
        $carrinho = $session->get('Carrinho') ?? [];

        echo view('_partials/header');
        echo view('cliente/Carrinho', ['Carrinho' => $carrinho]);
        echo view('_partials/footer');
    }

    public function adicionar($produto_id)
    {
        $session = session();
        $carrinho = $session->get('Carrinho') ?? [];

        $produtosDisponiveis = [
            //produtos da loja ok
            1 => ['id' => 1, 'nome' => '', 'preco' => 149.99],
            2 => ['id' => 2, 'nome' => '', 'preco' => 200.00],
            3 => ['id' => 3, 'nome' => '', 'preco' => 70.00],
            4 => ['id' => 4, 'nome' => '', 'preco' => 180.00],
            5 => ['id' => 5, 'nome' => '', 'preco' => 6.00],
            6 => ['id' => 6, 'nome' => '', 'preco' => 23.00],
            7 => ['id' => 7, 'nome' => '', 'preco' => 40.00],
            8 => ['id' => 8, 'nome' => '', 'preco' => 70.00],
            
            //perfumes ok
            9 => ['id' => 1, 'nome' => '', 'preco' => 149.99],
            10 => ['id' => 10, 'nome' => '', 'preco' => 170.00],
            11 => ['id' => 2, 'nome' => '', 'preco' => 200.00],
            12 => ['id' => 12, 'nome' => '', 'preco' => 180.00],
            13 => ['id' => 13, 'nome' => '', 'preco' => 200.00],
            14 => ['id' => 14, 'nome' => '', 'preco' => 159.99],
            15 => ['id' => 15, 'nome' => '', 'preco' => 159.99],
            16 => ['id' => 16, 'nome' => '', 'preco' => 150.00],

            //roupas ok
            17 => ['id' => 17, 'nome' => '', 'preco' => 149.99],
            18 => ['id' => 18, 'nome' => '', 'preco' => 160.00],
            19 => ['id' => 4, 'nome' => '', 'preco' => 180.00],
            20 => ['id' => 3, 'nome' => '', 'preco' => 100.00],
            21 => ['id' => 21, 'nome' => '', 'preco' => 140.00],
            22 => ['id' => 22, 'nome' => '', 'preco' => 140.00],
            23 => ['id' => 23, 'nome' => '', 'preco' => 70.00],
            24 => ['id' => 24, 'nome' => '', 'preco' => 75.00],

            //sabonetes ok
            25 => ['id' => 5, 'nome' => '', 'preco' => 6.00],
            26 => ['id' => 26, 'nome' => '', 'preco' => 44.00],
            27 => ['id' => 27, 'nome' => '', 'preco' => 23.00],
            28 => ['id' => 28, 'nome' => '', 'preco' => 20.00],
            29 => ['id' => 29, 'nome' => '', 'preco' => 7.00],
            30 => ['id' => 6, 'nome' => '', 'preco' => 23.00],
            31 => ['id' => 31, 'nome' => '', 'preco' => 32.00],
            32 => ['id' => 32, 'nome' => '', 'preco' => 6.50],
            
            //esfoliantes
            33 => ['id' => 33, 'nome' => 'Esfoliante labotrat de morango 300g', 'preco' => 25.00],
            34 => ['id' => 34, 'nome' => 'Esfoliante tree hutt vanilla 510g', 'preco' => 35.00],
            35 => ['id' => 35, 'nome' => 'Esfoliante Watermelon', 'preco' => 45.00],
            36 => ['id' => 36, 'nome' => 'Esfoliante labotrat de melancia 150g', 'preco' => 11.99],
            37 => ['id' => 37, 'nome' => 'Esfoliante labotrat de maracujá 150g', 'preco' => 11.99],
            38 => ['id' => 38, 'nome' => 'Sal esfoliante Bio Extractus 400g', 'preco' => 200.00],
            39 => ['id' => 7, 'nome' => 'Esfoliante watermelon tree hut 510g', 'preco' => 40.00],
            40 => ['id' => 8, 'nome' => 'Creme esfoliante coroporal lodorat', 'preco' => 39.99],
            //cremes/hidratantes
            41 => ['id' => 41, 'nome' => 'Esfoliante labotrat de morango 300g', 'preco' => 25.00],
            42 => ['id' => 42, 'nome' => 'Esfoliante tree hutt vanilla 510g', 'preco' => 35.00],
            43 => ['id' => 43, 'nome' => 'Esfoliante Watermelon', 'preco' => 45.00],
            44 => ['id' => 44, 'nome' => 'Esfoliante labotrat de melancia 150g', 'preco' => 11.99],
            45 => ['id' => 45, 'nome' => 'Esfoliante labotrat de maracujá 150g', 'preco' => 11.99],
            46 => ['id' => 46, 'nome' => 'Sal esfoliante Bio Extractus 400g', 'preco' => 200.00],
            47 => ['id' => 47, 'nome' => 'Esfoliante watermelon tree hut 510g', 'preco' => 40.00],
            48 => ['id' => 48, 'nome' => 'Creme esfoliante coroporal lodorat', 'preco' => 39.99],


        ];

        if (array_key_exists($produto_id, $produtosDisponiveis)) {
            if (isset($carrinho[$produto_id])) {
                $carrinho[$produto_id]['quantidade'] += 1; // CORRIGIDO
            } else {
                $produto = $produtosDisponiveis[$produto_id];
                $produto['quantidade'] = 1;
                $carrinho[$produto_id] = $produto;
            }

            $session->set('Carrinho', $carrinho);
        }

        return redirect()->to(base_url('cliente/Carrinho'));
    }
    public function salvar_cartao()
{
    $dadosCartaoModel = new \App\Models\DadosCartaoModel();

    $data = [
        'nome_cartao' => $this->request->getPost('nome_cartao'),
        'numero_cartao' => $this->request->getPost('numero_cartao'),
        'validade' => $this->request->getPost('validade'),
        'cvv' => $this->request->getPost('cvv'),
    ];

    if ($dadosCartaoModel->insert($data)) {
        // Salvou com sucesso, redireciona a pagina pedido
        return redirect()->to(base_url('cliente/entrega_produto'));
    } else {
        //Se falhar, redireciona para o formulário com erro
        return redirect()->back()->with('error', 'Falha ao salvar dados do cartão.');
    }
}



public function confirmarPedido()
{
    $pedidoModel = new PedidoModel();

    $dados = [
        'nome'        => $this->request->getPost('nome'),
        'telefone'    => $this->request->getPost('telefone'),
        'email'       => $this->request->getPost('email'),
        'cep'         => $this->request->getPost('cep'),
        'rua'         => $this->request->getPost('rua'),
        'numero'      => $this->request->getPost('numero'),
        'complemento' => $this->request->getPost('complemento'),
        'bairro'      => $this->request->getPost('bairro'),
        'cidade'      => $this->request->getPost('cidade'),
        'estado'      => $this->request->getPost('estado'),
        'referencia'  => $this->request->getPost('referencia'),
        'observacoes' => $this->request->getPost('observacoes'),
    ];

    // Salva o pedido no banco
    $pedidoModel->insert($dados);

    // Agora pega seleciona os produtos comprados
    $session = session();
    $produtosComprados = $session->get('Carrinho') ?? [];

    // Passa os produtos para a sessão para exibir na confirmação
    $session->set('produtos_comprados', $produtosComprados);

    // Limpa o carrinho 
    $session->remove('Carrinho');

    // Redireciona para a página de confirmação do pedido
    return redirect()->to(base_url('cliente/pedidoConfirmado'))->with('mensagem', 'Pedido confirmado com sucesso!');
}

public function pedidoConfirmado()
{
    $session = session();
    $produtos = $session->get('produtos_comprados') ?? [];

    return view('cliente/pedido_confirmado', ['produtos' => $produtos]);
}
    public function limparCarrinho()
    {
        session()->remove('Carrinho');
        return redirect()->to('cliente/carrinho')->with('mensagem', 'Carrinho limpo com sucesso!');
    }
    public function obrigado()
{
    return view('obrigado');
}

    public function novo(){
        return view('cliente/cadastro');
    }

    public function login(){
        return view('cliente/login');
    }

    public function voltar(){
        return view('cliente/loja');
    }

    public function perfumes(){
        echo view('_partials/header');
        echo view('cliente/perfumes');
        echo view('_partials/footer');
    }
    public function contato_sucesso(){
        echo view('_partials/header');
        echo view('cliente/contato_sucesso');
        echo view('_partials/footer');
    }

    public function Roupas(){
        echo view('_partials/header');
        echo view('cliente/Roupas');
        echo view('_partials/footer');
    }
    public function entrega_produto(){
        echo view('_partials/header');
        echo view('cliente/entrega_produto');
        echo view('_partials/footer');
    }
   
   



    public function Sabonetes(){
        echo view('_partials/header');
        echo view('cliente/Sabonetes');
        echo view('_partials/footer');
    }

    public function Esfoliantes(){
        echo view('_partials/header');
        echo view('cliente/Esfoliantes');
        echo view('_partials/footer');
    }

    public function Cremes_Hidratantes(){
        echo view('_partials/header');
        echo view('cliente/Cremes_Hidratantes');
        echo view('_partials/footer');
    }

   
    public function historico()
{
    $data['cliente'] = $this->clienteModel->findAll();
    return view('cliente/historico', $data);
}


    public function pagar(){
        echo view('_partials/header');
        echo view('cliente/pagar');
        echo view('_partials/footer');
    }

    public function pagar_cartao(){
        echo view('_partials/header');
        echo view('cliente/pagar_cartao');
        echo view('_partials/footer');
    }

    public function processar_cartao(){
        echo view('_partials/header');
        echo view('cliente/processar_cartao');
        echo view('_partials/footer');
    }

    public function pagar_boleto(){
        echo view('_partials/header');
        echo view('cliente/pagar_boleto');
        echo view('_partials/footer');
    }

    public function gerar_boleto(){
        echo view('_partials/header');
        echo view('cliente/gerar_boleto');
        echo view('_partials/footer');
    }

    public function pagar_pix(){
        echo view('_partials/header');
        echo view('cliente/pagar_pix');
        echo view('_partials/footer');
    }

    public function Produto(){
        echo view('_partials/header');
        echo view('cliente/Produto');
        echo view('_partials/footer');
    }

    public function cadastro(){
        echo view('_partials/header');
        echo view('cliente/cadastro');
        echo view('_partials/footer');
    }

    public function inserir()
    {
        $dados = $this->request->getPost();

        if (!isset($dados['senha'], $dados['confirma_senha']) || $dados['senha'] !== $dados['confirma_senha']) {
            return redirect()->back()->withInput()->with('erro', 'As senhas não coincidem.');
        }

        unset($dados['confirma_senha']);
        $dados['senha'] = password_hash($dados['senha'], PASSWORD_DEFAULT);

        $this->clienteModel->save($dados);
        return redirect()->to('cliente/login')->with('sucesso', 'Cadastro realizado com sucesso, Faça login e visite nossa loja!!');
    }

    public function editar($id){
        $cliente = $this->clienteModel->find($id);
        echo view('_partials/header');
        echo view('cliente/edita', ['cliente' => $cliente]);
        echo view('_partials/footer');
    }
    
    public function atualizar($id){
        $cliente = $this->request->getPost();
        $this->clienteModel->update($id, $cliente);
        return redirect()->to('cliente/index');
    }

    public function excluir($id){
        $this->clienteModel->delete($id);
        return redirect()->to('cliente/index');
    }

    public function loja(){
        echo view('_partials/header');
        echo view('cliente/loja');
        echo view('_partials/footer');
    }
   
    
    public function compra(){
        echo view('_partials/header');
        echo view('cliente/compra');
        echo view('_partials/footer');
    }
   public function MeuPerfil()
{
    $session = session();

    // Checar se o cliente está logado
    if (!$session->get('logado')) {
        return redirect()->to(base_url('cliente/login'));
    }

    $data = [
        'nome'  => $session->get('nome'),
        'email' => $session->get('email'),
    ];

    return view('cliente/MeuPerfil', $data);
}

    public function index(){
        echo view('_partials/header');
        echo view('cliente/index');
        echo view('_partials/footer');
    }

    public function questionario(){
        echo view('_partials/header');
        echo view('cliente/questionario');
        echo view('_partials/footer');
    }

    public function tutorial(){
        echo view('_partials/header');
        echo view('cliente/tutorial');
        echo view('_partials/footer');
    }

    public function sobre(){
        echo view('_partials/header');
        echo view('cliente/sobre');
        echo view('_partials/footer');
    }

    public function serviços(){
        echo view('_partials/header');
        echo view('cliente/serviços');
        echo view('_partials/footer');
    }

    public function contato(){
        echo view('_partials/header');
        echo view('cliente/contato');
        echo view('_partials/footer');
    }
  

    public function resultado_quiz()
    {
        $respostas_certas = [
            'q1' => 'certo',
            'q2' => 'certo',
            'q3' => 'certo',
            'q4' => 'certo',
            'q5' => 'certo',
            'q6' => 'certo',
            'q7' => 'certo',
        ];
    
        $post = $this->request->getPost();
    
        $acertos = 0;
        foreach ($respostas_certas as $pergunta => $resposta_certa) {
            if (isset($post[$pergunta]) && $post[$pergunta] === $resposta_certa) {
                $acertos++;
            }
        }
    
        
        echo "Você acertou $acertos de 7 perguntas!";
    }
    


    

    public function irloja(){
        return redirect()->to('cliente/loja');
    }
    

public function autenticar()
{
    $email = $this->request->getPost('email');
    $senha = $this->request->getPost('senha');

   
    $cliente = $this->clienteModel->where('email', $email)->first();

  
    if ($cliente && password_verify($senha, $cliente['senha'])) {
      
        $session = session();
        $session->set([
            'cliente_id' => $cliente['id'], 
            'nome'       => $cliente['nome'],  
            'email'      => $cliente['email'],  
            'logado'     => true, 
        ]);

       
        return redirect()->to(base_url('cliente/loja')); 
    } else {
       
        session()->setFlashdata('erro', 'Email ou senha incorretos.');
        return redirect()->to(base_url('cliente/login'));
    }
}



}