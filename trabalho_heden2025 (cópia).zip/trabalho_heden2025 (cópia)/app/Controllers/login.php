<?php

namespace App\Controllers;

use App\Models\UsuarioModel;

class Login extends BaseController
{
    public function index()
    {
        helper(['form']);
        echo view('login_view'); // página com formulário de login
    }

    public function autenticar()
    {
        helper(['form']);
        $session = session();
        $usuarioModel = new UsuarioModel();

        $email = $this->request->getPost('email');
        $senha = $this->request->getPost('senha');

        // Validar os dados (pode melhorar depois)
        if (!$email || !$senha) {
            return redirect()->back()->with('error', 'Preencha todos os campos');
        }

        $usuario = $usuarioModel->getByEmail($email);

        if ($usuario) {
            
            if (password_verify($senha, $usuario['senha'])) {
               
                $sessData = [
                    'id' => $usuario['id'],
                    'email' => $usuario['email'],
                    'nome' => $usuario['nome'],
                    'logado' => true
                ];
                $session->set($sessData);
                return redirect()->to(base_url('cliente/index'));
            } else {
                return redirect()->back()->with('error', 'Senha incorreta');
            }
        } else {
            return redirect()->back()->with('error', 'Usuário não encontrado');
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to(base_url('login'));
    }
}