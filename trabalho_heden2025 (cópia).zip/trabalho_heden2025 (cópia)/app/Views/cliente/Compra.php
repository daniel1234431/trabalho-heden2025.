<style>
    .comp{
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    @keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(-20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
    .comprarr{
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    
</style>

<div class="form-container">
        <h1 class="titl">Cadastro de compra</h1>

        <?= form_open('Cliente/inserir') ?>
            <div class="form2">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" placeholder="Digite seu nome" required>
            </div>
            <div class="form2">
                <label for="telefone">Telefone:</label>
                <input type="tel" name="telefone" id="telefone" placeholder="Digite seu número de telefone" required>
            </div>

            <div class="form2">
                <label for="email">cpf:</label>
                <input type="email" name="email" id="email" placeholder="nome@gmail.com" required>
            </div>

            <div class="form2">
                <label for="senha">endereço:</label>
                <input type="password" name="senha" id="senha" required>
            </div>

            <div class="form2">
                <label for="confirma_senha">:</label>
                <input type="password" name="confirma_senha" id="confirma_senha" required>
            </div>

            <button type="submit">Cadastrar</button>
        <?= form_close() ?>

        <div class="voltar">
            <?= anchor('Cliente', 'Voltar') ?>
        </div>
        <br>
    <div class="comp">
        <?= anchor('cliente/Carrinho', 'Comprar', ['class' => 'btn']) ?>
    </div>


    <div class="comprarr" data-bs-theme="light">
  <button class="botaodecompra" type="button" id="dropdownMenuButtonLight" data-bs-toggle="dropdown" aria-expanded="false">
    Default dropdown
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButtonLight">
    <li><a class="dropdown-item active" href="#">Action</a></li>
    <li><a class="dropdown-item" href="#">Action</a></li>
    <li><a class="dropdown-item" href="#">Another action</a></li>
    <li><a class="dropdown-item" href="#">Something else here</a></li>
    <li><hr class="dropdown-divider"></li>
    <li><a class="dropdown-item" href="#">Separated link</a></li>
  </ul>
</div>

<div class="dropdown" data-bs-theme="dark">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButtonDark" data-bs-toggle="dropdown" aria-expanded="false">
    Dark dropdown
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButtonDark">
    <li><a class="dropdown-item active" href="#">Action</a></li>
    <li><a class="dropdown-item" href="#">Action</a></li>
    <li><a class="dropdown-item" href="#">Another action</a></li>
    <li><a class="dropdown-item" href="#">Something else here</a></li>
    <li><hr class="dropdown-divider"></li>
    <li><a class="dropdown-item" href="#">Separated link</a></li>
  </ul>
</div>