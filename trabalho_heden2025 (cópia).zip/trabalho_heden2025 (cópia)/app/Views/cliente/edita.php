<h2>Editar #<?=$cliente['id']?></h2>
<?=form_open('Cliente/atualizar/'.$cliente['id'])?>
    <label>Nome: </label>
    <input type= "text" name='nome'id='nome' value="<?=$cliente['nome']?>">
    <div class= 'row w-50 mt-3'>
        <div class= "btn-group" role= 'group'>
    <button type='submit' class='btn btn-primary'>
    Atualizar
</button>
<?=anchor(
    'cliente/excluir/'.$cliente ['id'],
    'Excluir',
    ['class' => 'btn btn-danger']
    
)?>

<?=anchor(
    'cliente',
    'voltar',
    ['class' => 'btn btn-secondary']
    )?>
    </div>
</div>
<?=form_close()?>