<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Carrinho de Compras</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f6f6f6;
            padding: 20px;
            margin: 0;
        }

        h1 {
            text-align: center;
            margin-top: 20px;
            color: #333;
        }

        table {
            width: 90%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        h3 {
            text-align: center;
            color: #333;
            margin-top: 30px;
        }

        .button-container {
            text-align: left;
            margin: 20px;
        }

        .btn {
            background-color: #1e90ff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-size: 16px;
        }

        .btn:hover {
            background-color: #0b78d1;
        }

        form {
            text-align: center;
            margin-top: 20px;
        }

        form button {
            background-color: #ff4d4d;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
        }

        form button:hover {
            background-color: #cc0000;
        }

        p {
            text-align: center;
            font-size: 18px;
            color: #666;
        }
        .botoes{
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
        }
        .footer{
        background-color:black;
        color: white;
        text-align:center;
        padding: 0%;
        position:fixed;
        bottom: 0;
        width: 100%;
    }
    </style>
</head>
<body>

<div class="button-container">
    <?= anchor('Cliente/loja', 'Voltar', ['class' => 'btn']) ?>
</div>

<h1>Suas compras</h1>

<?php if (!empty($Carrinho)): ?> 
    <table>
        <thead>
            <tr>
                <th>Produto</th>
                <th>Preço</th>
                <th>Quantidade</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($Carrinho as $item): ?>
                <tr>
                    <td><?= esc($item['nome']) ?></td>
                    <td><?= number_format($item['preco'], 2, ',', '.') ?> R$</td>
                    <td><?= esc($item['quantidade']) ?></td>
                    <td><?= number_format($item['preco'] * $item['quantidade'], 2, ',', '.') ?> R$</td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
      <!--total de itens-->           
    <h3>Total: 
        <?= number_format(array_sum(array_map(function($item) { 
            return $item['preco'] * $item['quantidade']; 
        }, $Carrinho)), 1, ',', '.') ?> R$
    </h3>

    <h3>Quantidade de produtos no carrinho: 
        <?= array_sum(array_column($Carrinho, 'quantidade')) ?>
     <!--forma de pagamento do produto-->
    <div class="botoes">
    <form action="<?= base_url('cliente/pagar') ?>" method="post">
        <button type="submit">forma de pagamento</button>
    </form>
    
     <!--limpar carrinho de compras-->
    <form action="<?= base_url('cliente/limparCarrinho') ?>" method="post">
        <button type="submit">Limpar Carrinho</button>
    </form>

     <!--adicionar mais produtos ao carrinho-->
    <form action="<?= base_url('cliente/loja') ?>" method="post">
        <button type="submit">Adicionar mais</button>
    </form>
    </div>
    
<?php else: ?>
    <p>Seu carrinho está vazio.</p>
<?php endif; ?>



</div>
</body>
</html>