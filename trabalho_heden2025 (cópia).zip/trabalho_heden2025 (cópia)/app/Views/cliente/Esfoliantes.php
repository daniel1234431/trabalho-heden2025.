<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <title>Galeria com Barra de Pesquisa</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <style>
    :root {
      --verde-fundo: #f0f9f4;
      --verde-caixa: #e3f8ec;
      --verde-claro: #d2f5e3;
      --verde-texto-suave: #4a7056;
      --verde-botao: #a1dbb2;
      --verde-botao-hover: #88c9a3;
    }

    body {
      background-color: var(--verde-fundo);
      color: var(--verde-texto-suave);
      font-family: "Segoe UI", sans-serif;
      margin: 0;
    }

    .topo {
      background: linear-gradient(90deg, #2E7D32, #81C784);
      display: flex;
      justify-content: space-around;
      align-items: center;
      padding: 7px;
      width: 100%;
      z-index: 1000;
      font-weight: bold;
      box-shadow: 0 4px 6px rgba(0,0,0,0.3);
      animation: fadeIn 0.6s ease-in-out;
    }

    .topo li {
      list-style: none;
    }

    .topo li a {
      color: #ffffff;
      text-decoration: none;
      font-weight: bold;
      padding: 10px 16px;
      border-radius: 6px;
      transition: background-color 0.3s ease;
    }

    .topo li a:hover {
      background: linear-gradient(45deg, var(--verde-caixa), var(--verde-claro));
      color: white;
      box-shadow: 0 4px 6px rgba(0,0,0,0.9);
    }

    .div4 {
      position: fixed;
      top: 9px;
      left: 12px;
      background-color: white;
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 15px;
      z-index: 1000;
      box-shadow: 0 4px 6px rgba(0,0,0,0.9);
      border-radius: 8px;
      font-weight: bold;
      animation: fadeIn 0.6s ease-in-out;
    }

    .ps {
      color: black;
      font-size: 22px;
      margin: 0;
    }

    #searchInput {
      width: 300px;
      padding: 8px;
      font-size: 10px;
      border: 1px solid #81C784;
      border-radius: 8px;
      background-color: #F5F5F5;
      box-shadow: 0 4px 6px rgba(0,0,0,0.9);
      font-weight: bold;
    }

    .search-button {
      background: transparent;
      border: none;
      cursor: pointer;
    }

    .search-button i {
      font-size: 18px;
      color: #555;
    }

    .galeria {
      display: flex;
      flex-wrap: wrap;
      gap: 30px;
      justify-content: center;
      margin-top: 130px;
      padding: 20px;
    }

    .imagem-container1 {
      margin-bottom: 20px;
      border: 2px solid #A5D6A7;
      padding: 20px;
      border-radius: 15px;
      width: 400px;
      text-align: center;
      background-color: transparent;
      box-shadow: 0 4px 6px rgba(0,0,0,0.9);
      animation: fadeIn 0.6s ease-in-out;
    }

    .produto-img {
      width: 100%;
      max-width: 250px;
      height: 250px;
      object-fit: cover;
      border-radius: 15px;
      margin-top: 20px;
    }

    .cart-button {
      margin-top: 10px;
    }

    .cart-button button {
      background-color: #014421;
      color: white;
      padding: 8px 15px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: bold;
    }

    .linkt {
      text-decoration: none;
      color: white;
      font-weight: bold;
    }

    .linkt:hover {
      color: black;
    }

    .elevate {
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .elevate:hover {
      transform: translateY(-10px);
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    }

    .drop {
      position: fixed;
      top: 10px;
      right: 10px;
      z-index: 1000;
    }

    .btn.btn-secondary.dropdown-toggle {
      background-color: #014421;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 10px;
      font-weight: bold;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(-20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @media (max-width: 500px) {
      .div4 {
        flex-direction: column;
        align-items: flex-start;
      }

      .topo {
        flex-direction: column;
        align-items: flex-start;
      }
    }
  </style>
</head>
<body>


<div class="drop" data-bs-theme="dark">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButtonDark" data-bs-toggle="dropdown" aria-expanded="false">
    <i class="fas fa-bars"></i> Menu
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButtonDark">
    <li><a class="dropdown-item" href="<?= base_url('cliente/carrinho') ?>">🛒 Carrinho</a></li>
    <li><a class="dropdown-item" href="<?= base_url('cliente/historico') ?>">📜 Histórico</a></li>
    <li><a class="dropdown-item" href="<?= base_url('cliente/loja') ?>">🏠 Início</a></li>
  </ul>
</div>

<div class="div4">
  <h2 class="ps">Pesquisar</h2>
  <div class="search-container">
    <input type="text" id="searchInput" placeholder="Digite para buscar...">
    <button type="submit" class="search-button"><i class="fa fa-search"></i></button>
  </div>
</div>

<ul class="topo">
  <li><a class="linkt" href="<?= base_url('cliente/perfumes') ?>">Perfumes</a></li>
  <li><a class="linkt" href="<?= base_url('cliente/roupas') ?>">Roupas</a></li>
  <li><a class="linkt" href="<?= base_url('cliente/sabonetes') ?>">Sabonetes</a></li>
  <li><a class="linkt" href="<?= base_url('cliente/esfoliantes') ?>">Esfoliantes</a></li>
  <li><a class="linkt" href="<?= base_url('cliente/cremes_hidratantes') ?>">Cremes/Hidratantes</a></li>
</ul>

<div class="galeria">
  <?php for ($i = 1; $i <= 8; $i++): ?>
    <div class="elevate">
      <div class="imagem-container1">
        <img src="/produto<?= $i ?>.<?= ($i % 3 === 0 ? 'webp' : ($i % 2 === 0 ? 'webp' : 'jpeg')) ?>" alt="Produto <?= $i ?>" class="produto-img">
        <div class="cart-button">
          <a href="<?= base_url('cliente/adicionar/' . $i) ?>">
            <button><span class="cart-icon">🛒</span> COMPRAR</button>
          </a>
        </div>
      </div>
    </div>
  <?php endfor; ?>
</div>


 
  <script>
    const searchInput = document.getElementById("searchInput");
    const items = document.querySelectorAll(".topo li");

    searchInput.addEventListener("keyup", function () {
      const filter = searchInput.value.toLowerCase();
      items.forEach(item => {
        const text = item.textContent.toLowerCase();
        item.style.display = text.includes(filter) ? "" : "none";
      });
    });
  </script>

</body>
</html>
